const url_app = 'http://localhost:3000/'




async function login() {
    try {
        const res = await fetch('http://localhost:3000/')
        const data = await res.json();
        console.log(data)
    } catch (error) {
        console.log("Error al obtener usuarios:",error)
    }
}

async function register() {
    try {
        const res = await fetch ('http://localhost:3000/admin' ,{
            method: 'POST',
            headers:{
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({})
        });

        const nuevo = await res.json();
        console.log("Usuario nuevo registrado:", nuevo);
    } catch (error) {
        console.log("Error al registrar usuario:",error)

    }
}

async function actualizarevents() {
    try {
        const res = await fetch ('http://localhost:3000/' ,{
            method: 'PATCH',
            headers:{
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({events, newname})
        });
        const updated = await res.json();
        console.log("Evento actualizdo", updated)
    } catch (error) {
        console.log("Error al actualizar:",error)
    }
    
}

async function deleteevents(id) {
    try {
        await fetch ('http://localhost:3000/' ,{
            method: 'DELETE',
    });
    } catch (error) {
        console.log("Error al eliminar el evento:",error)
    }
    
}